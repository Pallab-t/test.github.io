<?php

namespace Terminal42\ServiceAnnotationBundle;

/**
 * Marker interface for Symfony service auto configuration
 */
interface ServiceAnnotationInterface
{
}
