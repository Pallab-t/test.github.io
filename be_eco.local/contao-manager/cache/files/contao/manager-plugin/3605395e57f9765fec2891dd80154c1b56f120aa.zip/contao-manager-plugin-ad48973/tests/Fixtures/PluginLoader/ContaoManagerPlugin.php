<?php

class ContaoManagerPlugin
{
}
