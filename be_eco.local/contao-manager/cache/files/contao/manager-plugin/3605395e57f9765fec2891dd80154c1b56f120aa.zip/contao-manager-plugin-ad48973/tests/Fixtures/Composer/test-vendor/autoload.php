<?php

throw new \RuntimeException('autoload.php successfully loaded');
