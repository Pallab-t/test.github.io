<?php

namespace Foo\Bar;

class FooBarPlugin
{
}
