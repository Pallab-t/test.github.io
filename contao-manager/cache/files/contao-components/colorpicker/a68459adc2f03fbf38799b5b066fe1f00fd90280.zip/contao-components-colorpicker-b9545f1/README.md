Color picker
============

This is a customized MooTools [color picker][1] package of the to be integrated
in [Contao Open Source CMS][2].


[1]: https://github.com/CBeloch/mooRainbow/
[2]: https://contao.org
