<?php

namespace Doctrine\Bundle\DoctrineBundle\Mapping;

/**
 * @deprecated since DoctrineBundle 1.11 and will be removed in 2.0. Use ContainerEntityListenerResolver instead.
 */
class ContainerAwareEntityListenerResolver extends ContainerEntityListenerResolver
{
}
