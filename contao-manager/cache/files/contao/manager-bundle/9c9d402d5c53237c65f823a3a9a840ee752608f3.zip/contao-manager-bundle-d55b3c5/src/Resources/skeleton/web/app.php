<?php

// Backwards compatibility
require __DIR__.'/index.php';
