<?php

namespace Knp\Bundle\TimeBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle as BaseBundle;

class KnpTimeBundle extends BaseBundle
{
}
